package com.paypal.bfs.test.bookingserv.impl;

import com.paypal.bfs.test.bookingserv.api.BookingResource;

import com.paypal.bfs.test.bookingserv.api.model.Booking;
import com.paypal.bfs.test.bookingserv.repository.BookingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class BookingResourceImpl implements BookingResource {
    @Autowired
    private BookingRepository bookingrepo;

    @Override
    public Booking create(Booking booking) {
        return bookingrepo.save(booking);
    }

    @Override
    public List<Booking> getAllBookings() {
        return bookingrepo.findAll();

    }

}
